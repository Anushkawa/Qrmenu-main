<html lang="@lang('en')">
<head>
    <title>Private Area</title>
    {{--    <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">--}}
    @vite(['resources/js/app.js'])
</head>
<body>
<div class="container">
    WEB PRIVATE AREA
</div>
</body>
</html>
