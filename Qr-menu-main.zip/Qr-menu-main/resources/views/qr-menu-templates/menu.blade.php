<html lang="@lang('en')">
<head>
    <title>Menu</title>
    {{--    <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">--}}
    @vite(['resources/js/app.js'])
</head>
<body>
<div class="container">
    WEB SHOW MENU
</div>
</body>
</html>
