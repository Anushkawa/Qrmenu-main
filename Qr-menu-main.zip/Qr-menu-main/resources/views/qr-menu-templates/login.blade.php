<html lang="@lang('en')">
<head>
    <title>Log in</title>
    {{--    <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">--}}
    @vite(['resources/js/app.js'])
</head>
<body>
<div class="container">
    WEB AUTH LOGIN
</div>
</body>
</html>
