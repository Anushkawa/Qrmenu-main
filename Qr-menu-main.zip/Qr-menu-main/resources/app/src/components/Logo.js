import logo from "../assets/qr-menu-logo.svg";
export function Logo() {
    return (<><img src={logo} alt="logo" className="logo"/></>);
}
