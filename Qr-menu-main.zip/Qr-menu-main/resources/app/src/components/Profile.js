import React from "react";

export function Profile() {
    return (
        <>
            <h1> PROFILE PAGE </h1>
        </>
    );
}
